<div class="section-menu-left">
    <div class="box-logo">
        <a href="{{ route('dashboard') }}" id="site-logo-inner">
            <img id="logo_header" alt="Mursalin Ecommerce" src="{{ asset('assets/images/logo/logo.png') }}"
                 data-light="{{ asset('assets/images/logo/logo.png') }}"
                 data-dark="{{ asset('assets/images/logo/logo-dark.png') }}">
        </a>
        <div class="button-show-hide"><i class="icon-menu-left"></i></div>
    </div>

    <div class="section-menu-left-wrap">
        <div class="sidebar-profile-card">
            <div class="wg-user">
                <div class="image">
                    <img src="{{ auth()->user()->image_url }}" alt="{{ auth()->user()->name }}">
                </div>
                <div class="flex flex-column min-w-0">
                    <div class="body-title-2 text-truncate">{{ auth()->user()->name }}</div>
                    <span class="sidebar-brand-subtitle">{{ ucfirst(auth()->user()->role) }} account</span>
                </div>
            </div>
        </div>

        <div class="sidebar-quick-actions">
            <div class="quick-title">Quick Actions</div>
            <a href="{{ route('products.create') }}"><i class="icon-plus"></i><span>Add Product</span></a>
            <a href="{{ route('orders.create') }}"><i class="icon-file-plus"></i><span>Create Order</span></a>
            <a href="{{ route('reports.index') }}"><i class="icon-pie-chart"></i><span>View Reports</span></a>
        </div>

        <div class="center">
            <div class="center-item">
                <div class="center-heading">Main Home</div>
                <ul class="menu-list">
                    <li class="menu-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                        <a href="{{ route('dashboard') }}" class="menu-item-button">
                            <div class="icon"><i class="icon-grid"></i></div>
                            <div class="text">Dashboard</div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="center-item">
                <div class="center-heading">Catalog</div>
                <ul class="menu-list">
                    <li class="menu-item has-children {{ request()->is('products*') ? 'active' : '' }}">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-shopping-cart"></i></div>
                            <div class="text">Products</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('products.create') ? 'active' : '' }}" href="{{ route('products.create') }}"><div class="text">Add Product</div></a></li>
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('products.index') ? 'active' : '' }}" href="{{ route('products.index') }}"><div class="text">Product List</div></a></li>
                        </ul>
                    </li>
                    <li class="menu-item has-children {{ request()->is('categories*') ? 'active' : '' }}">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-layers"></i></div>
                            <div class="text">Categories</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('categories.index') ? 'active' : '' }}" href="{{ route('categories.index') }}"><div class="text">Category List</div></a></li>
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('categories.create') ? 'active' : '' }}" href="{{ route('categories.create') }}"><div class="text">New Category</div></a></li>
                        </ul>
                    </li>
                    <li class="menu-item has-children {{ request()->is('brands*') ? 'active' : '' }}">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-box"></i></div>
                            <div class="text">Brands</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('brands.index') ? 'active' : '' }}" href="{{ route('brands.index') }}"><div class="text">Brand List</div></a></li>
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('brands.create') ? 'active' : '' }}" href="{{ route('brands.create') }}"><div class="text">Add Brand</div></a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <div class="center-item">
                <div class="center-heading">Sales</div>
                <ul class="menu-list">
                    <li class="menu-item has-children {{ request()->is('orders*') ? 'active' : '' }}">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-file-plus"></i></div>
                            <div class="text">Orders</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('orders.index') ? 'active' : '' }}" href="{{ route('orders.index') }}"><div class="text">Order List</div></a></li>
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('orders.create') ? 'active' : '' }}" href="{{ route('orders.create') }}"><div class="text">Create Order</div></a></li>
                        </ul>
                    </li>
                    <li class="menu-item {{ request()->is('reports*') ? 'active' : '' }}">
                        <a href="{{ route('reports.index') }}" class="menu-item-button">
                            <div class="icon"><i class="icon-pie-chart"></i></div>
                            <div class="text">Reports</div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="center-item">
                <div class="center-heading">Management</div>
                <ul class="menu-list">
                    <li class="menu-item has-children {{ request()->is('users*') ? 'active' : '' }}">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-user"></i></div>
                            <div class="text">Users</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('users.index') ? 'active' : '' }}" href="{{ route('users.index') }}"><div class="text">All Users</div></a></li>
                            <li class="sub-menu-item"><a class="{{ request()->routeIs('users.create') ? 'active' : '' }}" href="{{ route('users.create') }}"><div class="text">Add New User</div></a></li>
                        </ul>
                    </li>
                    <li class="menu-item {{ request()->routeIs('profile*') ? 'active' : '' }}">
                        <a href="{{ route('profile') }}" class="menu-item-button">
                            <div class="icon"><i class="icon-settings"></i></div>
                            <div class="text">Profile</div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
