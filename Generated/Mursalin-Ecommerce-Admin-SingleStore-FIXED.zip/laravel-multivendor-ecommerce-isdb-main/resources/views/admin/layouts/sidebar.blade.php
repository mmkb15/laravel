@php
    $active = fn ($route) => request()->routeIs($route) ? 'active' : '';
@endphp
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="{{ route('admin.dashboard') }}" class="brand-link">
            <img src="{{ asset('img/AdminLTELogo.png') }}" alt="AdminLTE Logo" class="brand-image opacity-75 shadow" />
            <span class="brand-text fw-light fs-6">Ecommerce Admin</span>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="mt-2" aria-label="Main navigation">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" data-accordion="false" id="navigation">
                <li class="nav-item">
                    <a href="{{ route('admin.dashboard') }}" class="nav-link {{ $active('admin.dashboard') }}">
                        <i class="nav-icon bi bi-speedometer"></i><p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-header">CATALOG</li>
                <li class="nav-item">
                    <a href="#" class="nav-link {{ $active('admin.products.*') }}"><i class="nav-icon bi bi-box-seam"></i><p>Products <i class="nav-arrow bi bi-chevron-right"></i></p></a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item"><a href="{{ route('admin.products.index') }}" class="nav-link {{ $active('admin.products.index') }}"><i class="nav-icon bi bi-circle"></i><p>All Products</p></a></li>
                        <li class="nav-item"><a href="{{ route('admin.products.create') }}" class="nav-link {{ $active('admin.products.create') }}"><i class="nav-icon bi bi-circle"></i><p>Add Product</p></a></li>
                        <li class="nav-item"><a href="{{ route('admin.categories.index') }}" class="nav-link {{ $active('admin.categories.*') }}"><i class="nav-icon bi bi-circle"></i><p>Categories</p></a></li>
                        <li class="nav-item"><a href="{{ route('admin.brands.index') }}" class="nav-link {{ $active('admin.brands.*') }}"><i class="nav-icon bi bi-circle"></i><p>Brands</p></a></li>
                    </ul>
                </li>
                <li class="nav-header">SALES</li>
                <li class="nav-item">
                    <a href="{{ route('admin.orders.index') }}" class="nav-link {{ $active('admin.orders.*') }}"><i class="nav-icon bi bi-cart-check"></i><p>Orders</p></a>
                </li>
                <li class="nav-header">PEOPLE</li>
                <li class="nav-item">
                    <a href="{{ route('admin.users.index') }}" class="nav-link {{ $active('admin.users.*') }}"><i class="nav-icon bi bi-people"></i><p>Users</p></a>
                </li>
                <li class="nav-header">ACCOUNT</li>
                <li class="nav-item">
                    <a href="{{ route('profile.edit') }}" class="nav-link {{ $active('profile.edit') }}"><i class="nav-icon bi bi-person-circle"></i><p>My Profile</p></a>
                </li>
                <li class="nav-item">
                    <form action="{{ route('admin.logout') }}" method="POST">
                        @csrf
                        <button class="nav-link border-0 bg-transparent w-100 text-start" type="submit"><i class="nav-icon bi bi-box-arrow-right"></i><p>Logout</p></button>
                    </form>
                </li>
            </ul>
        </nav>
    </div>
</aside>
