@extends('admin.layouts.app')
@section('title', 'Orders')
@section('content')
<main class="app-main" id="main"><x-admin.content-header title="Orders"/><div class="app-content"><div class="container-fluid">
<x-admin.success-flash-message />
<div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h3 class="card-title">Order Management</h3><form method="GET" class="d-flex gap-2"><select name="status" class="form-select form-select-sm"><option value="">All Statuses</option>@foreach(['pending','processing','shipped','delivered','cancelled'] as $status)<option value="{{ $status }}" @selected(request('status')===$status)>{{ ucfirst($status) }}</option>@endforeach</select><button class="btn btn-sm btn-outline-primary">Filter</button></form></div></div>
<div class="card-body p-0"><div class="table-responsive"><table class="table table-hover align-middle m-0"><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th class="text-end">Action</th></tr></thead><tbody>
@forelse($orders as $order)<tr><td><span class="fw-medium">{{ $order->order_number }}</span></td><td>{{ $order->customer?->name }}</td><td>{{ $order->created_at->format('M j, Y H:i') }}</td><td>৳ {{ number_format($order->total,2) }}</td><td><span class="badge {{ match($order->status){'delivered'=>'text-bg-success','cancelled'=>'text-bg-danger','shipped'=>'text-bg-info','processing'=>'text-bg-primary',default=>'text-bg-warning'} }}">{{ ucfirst($order->status) }}</span></td><td class="text-end"><a href="{{ route('admin.orders.show',$order) }}" class="btn btn-sm btn-outline-success"><i class="bi bi-eye"></i></a></td></tr>
@empty<tr><td colspan="6" class="text-center py-5">No orders found.</td></tr>@endforelse
</tbody></table></div></div><x-admin.pagination :for="$orders"/></div>
</div></div></main>
@endsection
