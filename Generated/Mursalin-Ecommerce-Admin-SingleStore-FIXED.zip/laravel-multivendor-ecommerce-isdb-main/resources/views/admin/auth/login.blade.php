@extends('admin.layouts.guest')
@section('content')
<main class="login-box" id="main" tabindex="-1">
    <h1 class="login-logo"><a href="{{ route('admin.login') }}">Ecommerce Admin</a></h1>
    <div class="card"><div class="card-body login-card-body">
        <p class="login-box-msg">Sign in to start your admin session</p>
        <div class="text-center"><x-admin.error-message name="email" /><x-admin.error-message name="password" /></div>
        <div class="alert alert-light border small"><strong>Demo:</strong> admin@example.com / password</div>
        <form action="{{ route('admin.login') }}" method="post">@csrf
            <label class="visually-hidden" for="loginEmail">Email</label>
            <div class="input-group mb-3"><input id="loginEmail" type="email" name="email" class="form-control" placeholder="Email" value="{{ old('email','admin@example.com') }}"><div class="input-group-text"><span class="bi bi-envelope"></span></div></div>
            <label class="visually-hidden" for="loginPassword">Password</label>
            <div class="input-group mb-3"><input id="loginPassword" type="password" name="password" class="form-control" placeholder="Password" value="password"><div class="input-group-text"><span class="bi bi-lock-fill"></span></div></div>
            <div class="row"><div class="col-8"><div class="form-check"><input class="form-check-input" type="checkbox" name="remember" value="1" id="remember"><label class="form-check-label" for="remember">Remember Me</label></div></div><div class="col-4"><div class="d-grid"><button type="submit" class="btn btn-primary">Sign In</button></div></div></div>
        </form>
        <p class="mt-3 mb-0"><a href="{{ route('password.request') }}">I forgot my password</a></p>
    </div></div>
</main>
@endsection
