@extends('admin.layouts.app')
@section('title', 'Edit Product')
@section('styles')<style>@media (min-width: 50em){.filepond--item{width:calc(33.33% - .5em)}}@media (min-width:30em) and (max-width:50em){.filepond--item{width:calc(50% - .5em)}}</style>@endsection
@section('scripts')@vite(['resources/js/filepond.js'])@endsection
@section('content')
<main class="app-main" id="main"><x-admin.content-header title="Edit Product"/><div class="app-content"><div class="container-fluid">
<form action="{{ route('admin.products.update',$product) }}" method="POST" enctype="multipart/form-data">@csrf @method('PUT')
<div class="row"><div class="col-lg-8 order-2 order-lg-1">
<div class="card card-primary card-outline mb-3"><div class="card-header"><h3 class="card-title">General Information</h3></div><div class="card-body"><div class="row g-3">
<x-admin.form.input class="col-12" label="Product name" name="name" value="{{ old('name',$product->name) }}"/>
<x-admin.form.input class="col-md-6" label="SKU" name="sku" value="{{ old('sku',$product->sku) }}"/>
<x-admin.form.select class="col-md-3" label="Category" name="category_id">@foreach($categories as $category)<option value="{{ $category->id }}" @selected(old('category_id',$product->category_id)==$category->id)>{{ $category->name }}</option>@endforeach</x-admin.form.select>
<x-admin.form.select class="col-md-3" label="Brand" name="brand_id">@foreach($brands as $brand)<option value="{{ $brand->id }}" @selected(old('brand_id',$product->brand_id)==$brand->id)>{{ $brand->name }}</option>@endforeach</x-admin.form.select>
<x-admin.form.textarea class="col-12" label="Description" name="description" value="{{ old('description',$product->description) }}"/>
</div></div></div>
<div class="card card-primary card-outline mb-3"><div class="card-header"><h3 class="card-title">Pricing & Inventory</h3></div><div class="card-body"><div class="row g-3">
<x-admin.form.input class="col-md-4" label="Price" type="number" name="base_price" value="{{ old('base_price',$product->base_price) }}">৳</x-admin.form.input>
<x-admin.form.input class="col-md-4" label="Offer Price" type="number" name="offer_price" value="{{ old('offer_price',$product->offer_price) }}">৳</x-admin.form.input>
<x-admin.form.input class="col-md-4" label="Stock" type="number" name="stock" value="{{ old('stock',$product->stock) }}"/>
</div></div></div>
<div class="d-flex gap-2"><x-admin.buttons.submit label="Update Product"/><x-admin.buttons.cancel href="{{ route('admin.products.index') }}"/></div>
</div><div class="col-lg-4 order-1 order-lg-2"><div class="card card-outline card-primary mb-3"><div class="card-header"><h3 class="card-title">Product Images</h3></div><div class="card-body">@if(!empty($product->images))<div class="d-flex flex-wrap gap-2 mb-3">@foreach($product->images as $path)<img src="{{ \Illuminate\Support\Facades\Storage::url($path) }}" style="width:72px;height:72px;object-fit:cover" class="rounded">@endforeach</div>@endif<input type="file" id="product_image" class="filepond" accept="image/*" name="product_image[]" multiple><p class="text-secondary fs-7 mt-2 mb-0">Uploading new images replaces current images.</p></div></div></div></div>
</form></div></div></main>
@endsection
