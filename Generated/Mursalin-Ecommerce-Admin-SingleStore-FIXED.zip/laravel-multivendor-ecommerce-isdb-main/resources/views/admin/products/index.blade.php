@extends('admin.layouts.app')
@section('title', 'Products')
@section('content')
<main class="app-main" id="main" tabindex="-1">
    <x-admin.content-header title="Products" />
    <div class="app-content"><div class="container-fluid">
        <x-admin.success-flash-message />
        @if(session('error'))<div class="alert alert-danger">{{ session('error') }}</div>@endif
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Product Catalog</h3>
                <x-admin.buttons.add href="{{ route('admin.products.create') }}" label="New Product" />
            </div>
            <div class="card-body p-0"><div class="table-responsive">
                <table class="table table-hover align-middle m-0">
                    <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Brand</th><th>Price</th><th>Stock</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    @forelse($products as $product)
                        <tr>
                            <td><div class="d-flex align-items-center">
                                @if(!empty($product->images[0]))<img src="{{ \Illuminate\Support\Facades\Storage::url($product->images[0]) }}" class="rounded me-2" style="width:42px;height:42px;object-fit:cover">@else<img src="{{ asset('img/prod-1.jpg') }}" class="rounded me-2" style="width:42px;height:42px;object-fit:cover">@endif
                                <span class="fw-medium">{{ $product->name }}</span>
                            </div></td>
                            <td><code>{{ $product->sku }}</code></td>
                            <td>{{ $product->category?->name }}</td><td>{{ $product->brand?->name }}</td>
                            <td>{{ number_format($product->offer_price ?: $product->base_price, 2) }}</td>
                            <td><span class="badge {{ $product->stock <= 5 ? 'text-bg-danger' : 'text-bg-success' }}">{{ $product->stock }}</span></td>
                            <td class="text-end"><div class="btn-group btn-group-sm">
                                <x-admin.buttons.view href="{{ route('admin.products.show', $product) }}" />
                                <x-admin.buttons.edit href="{{ route('admin.products.edit', $product) }}" />
                                <x-admin.buttons.delete item-name="{{ $product->name }}" item-delete-url="{{ route('admin.products.destroy', $product) }}" />
                            </div></td>
                        </tr>
                    @empty<tr><td colspan="7" class="text-center py-5 text-secondary">No products found.</td></tr>@endforelse
                    </tbody>
                </table>
            </div></div>
            <x-admin.pagination :for="$products" />
        </div>
        <x-admin.delete-modal />
    </div></div>
</main>
@endsection
