@extends('admin.layouts.app')
@section('title', 'My Profile')
@section('content')
<main class="app-main" id="main"><x-admin.content-header title="My Profile"/><div class="app-content"><div class="container-fluid">
@if(session('status'))<div class="alert alert-success">Profile updated successfully.</div>@endif
<div class="row g-3"><div class="col-lg-7"><div class="card card-primary card-outline"><div class="card-header"><h3 class="card-title">Account Information</h3></div><div class="card-body"><form method="POST" action="{{ route('profile.update') }}">@csrf @method('PATCH')
<x-admin.form.input class="col-12 mb-3" label="Name" name="name" value="{{ old('name',$user->name) }}"/>
<x-admin.form.input class="col-12 mb-3" label="Email" type="email" name="email" value="{{ old('email',$user->email) }}"/>
<x-admin.form.input class="col-12 mb-3" label="Phone" name="phone" value="{{ $user->phone }}"/>
<button class="btn btn-primary">Save Changes</button>
</form></div></div></div><div class="col-lg-5"><div class="card"><div class="card-header"><h3 class="card-title">Admin Account</h3></div><div class="card-body"><div class="d-flex align-items-center gap-3"><img src="{{ $user->profile_image ? \Illuminate\Support\Facades\Storage::url($user->profile_image) : asset('img/avatar.png') }}" class="rounded-circle" style="width:72px;height:72px;object-fit:cover"><div><div class="fw-semibold">{{ $user->name }}</div><div class="text-secondary">{{ $user->email }}</div><span class="badge text-bg-primary mt-1">{{ $user->role?->name }}</span></div></div></div></div></div></div>
</div></div></main>
@endsection
