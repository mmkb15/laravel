<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::withCount('products')->orderByDesc('id')->paginate(15);
        return view('admin.categories.index', compact('categories'));
    }

    public function store(Request $request)
    {
        $data = $request->validate(['name' => ['required', 'string', 'min:2', 'max:100', 'unique:categories,name']]);
        Category::create($data);
        return back()->with('success', 'Category added successfully.');
    }

    public function update(Request $request, Category $category)
    {
        $data = $request->validate(['name' => ['required', 'string', 'min:2', 'max:100', Rule::unique('categories', 'name')->ignore($category->id)]]);
        $category->update($data);
        return back()->with('success', 'Category updated successfully.');
    }

    public function destroy(Category $category)
    {
        if ($category->products()->exists()) {
            return back()->with('error', 'This category cannot be deleted while products are using it.');
        }
        $category->delete();
        return back()->with('success', 'Category deleted successfully.');
    }
}
