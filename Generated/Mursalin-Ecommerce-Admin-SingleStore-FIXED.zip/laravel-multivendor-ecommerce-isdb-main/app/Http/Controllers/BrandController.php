<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BrandController extends Controller
{
    public function index()
    {
        $brands = Brand::withCount('products')->orderByDesc('id')->paginate(15);
        return view('admin.brands.index', compact('brands'));
    }

    public function store(Request $request)
    {
        $data = $request->validate(['name' => ['required', 'string', 'min:2', 'max:100', 'unique:brands,name']]);
        Brand::create($data);
        return back()->with('success', 'Brand added successfully.');
    }

    public function update(Request $request, Brand $brand)
    {
        $data = $request->validate(['name' => ['required', 'string', 'min:2', 'max:100', Rule::unique('brands', 'name')->ignore($brand->id)]]);
        $brand->update($data);
        return back()->with('success', 'Brand updated successfully.');
    }

    public function destroy(Brand $brand)
    {
        if ($brand->products()->exists()) {
            return back()->with('error', 'This brand cannot be deleted while products are using it.');
        }
        $brand->delete();
        return back()->with('success', 'Brand deleted successfully.');
    }
}
