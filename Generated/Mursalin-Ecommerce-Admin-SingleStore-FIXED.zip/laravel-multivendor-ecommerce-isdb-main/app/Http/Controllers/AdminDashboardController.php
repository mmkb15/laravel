<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'products' => Product::count(),
            'categories' => Category::count(),
            'customers' => User::where('role_id', 2)->count(),
            'orders' => Order::count(),
            'sales' => Order::whereNotIn('status', ['cancelled'])->sum('total'),
            'brands' => Brand::count(),
        ];
        $recentOrders = Order::with('customer')->latest()->take(8)->get();
        $lowStockProducts = Product::with(['category', 'brand'])->where('stock', '<=', 5)->orderBy('stock')->take(8)->get();
        return view('admin.dashboard', compact('stats', 'recentOrders', 'lowStockProducts'));
    }
}
