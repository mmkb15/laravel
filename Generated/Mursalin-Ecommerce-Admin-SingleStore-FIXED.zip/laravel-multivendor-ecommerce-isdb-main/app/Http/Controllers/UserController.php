<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $roles = Role::whereIn('id', [1, 2])->get();
        $query = User::with('role')->whereIn('role_id', [1, 2])->latest('id');
        if ($request->filled('role_id')) {
            $query->where('role_id', $request->integer('role_id'));
        }
        $users = $query->paginate(15)->withQueryString();
        $role_id = $request->integer('role_id');
        return view('admin.users.index', compact('users', 'roles', 'role_id'));
    }

    public function roleIndex($role_id = null)
    {
        return redirect()->route('admin.users.index', ['role_id' => $role_id]);
    }

    public function create()
    {
        return view('admin.users.create', ['roles' => Role::whereIn('id', [1, 2])->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'min:3', 'max:100'],
            'role_id' => ['required', Rule::in([1, 2])],
            'email' => ['required', 'email', 'unique:users,email'],
            'phone' => ['required', 'string', 'max:30', 'unique:users,phone'],
            'password' => ['required', 'min:6', 'max:100', 'confirmed'],
            'profile_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp,avif', 'max:2048'],
        ]);

        $user = User::create([
            'name' => $data['name'],
            'role_id' => $data['role_id'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => Hash::make($data['password']),
            'email_verified_at' => now(),
        ]);

        if ($request->hasFile('profile_image')) {
            $user->profile_image = $request->file('profile_image')->store('profiles', 'public');
            $user->save();
        }

        return redirect()->route('admin.users.index')->with('success', 'User added successfully.');
    }

    public function edit(User $user)
    {
        abort_unless(in_array($user->role_id, [1, 2], true), 404);
        return view('admin.users.edit', [
            'roles' => Role::whereIn('id', [1, 2])->get(),
            'user' => $user,
        ]);
    }

    public function update(Request $request, User $user)
    {
        abort_unless(in_array($user->role_id, [1, 2], true), 404);

        $data = $request->validate([
            'name' => ['required', 'string', 'min:3', 'max:100'],
            'role_id' => ['required', Rule::in([1, 2])],
            'email' => ['required', 'email', Rule::unique('users', 'email')->ignore($user->id)],
            'phone' => ['required', 'string', 'max:30', Rule::unique('users', 'phone')->ignore($user->id)],
            'password' => ['nullable', 'min:6', 'max:100', 'confirmed'],
            'profile_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp,avif', 'max:2048'],
        ]);

        if ($user->id === auth()->id() && (int) $data['role_id'] !== 1) {
            return back()->withInput()->with('error', 'You cannot remove your own admin role.');
        }

        $user->name = $data['name'];
        $user->role_id = $data['role_id'];
        $user->email = $data['email'];
        $user->phone = $data['phone'];
        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();

        if ($request->hasFile('profile_image')) {
            if ($user->profile_image) {
                Storage::disk('public')->delete($user->profile_image);
            }
            $user->profile_image = $request->file('profile_image')->store('profiles', 'public');
            $user->save();
        }

        return redirect()->route('admin.users.index')->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->with('error', 'You cannot delete your own account.');
        }
        if ($user->profile_image) {
            Storage::disk('public')->delete($user->profile_image);
        }
        $user->delete();
        return redirect()->route('admin.users.index')->with('success', 'User deleted successfully.');
    }
}
