<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with('category', 'brand')->orderBy('id', 'desc')->paginate(15);

        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        $brands = Brand::all();
        $categories = Category::all();

        return view('admin.products.create', compact('brands', 'categories'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|min:3|max:100',
            'sku' => 'required|string|max:50|unique:products,sku',
            'stock' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'brand_id' => 'required|exists:brands,id',
            'description' => 'required|min:10|max:255',
            'base_price' => 'required|numeric|min:0',
            'offer_price' => 'nullable|numeric|min:0|lt:base_price',
            'product_image' => 'nullable|array',
            'product_image.*' => 'image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        $product = Product::create([
            'name' => $data['name'],
            'category_id' => $data['category_id'],
            'brand_id' => $data['brand_id'],
            'sku' => $data['sku'],
            'stock' => $data['stock'],
            'description' => $data['description'],
            'base_price' => $data['base_price'],
            'offer_price' => $data['offer_price'] ?? null,
        ]);

        if ($request->hasFile('product_image')) {
            $paths = [];
            foreach ($request->file('product_image') as $image) {
                $paths[] = $image->store('products', 'public');
            }
            $product->update(['images' => $paths]);
        }

        return redirect()->route('admin.products.index')->with('success', 'Product added successfully.');
    }

    public function show(Product $product)
    {
        return view('admin.products.show', compact('product'));
    }

    public function edit(Product $product)
    {
        $brands = Brand::all();
        $categories = Category::all();

        return view('admin.products.edit', compact('product', 'brands', 'categories'));
    }

    public function update(Request $request, Product $product)
    {
        $data = $request->validate([
            'name' => 'required|min:3|max:100',
            'sku' => 'required|string|max:50|unique:products,sku,' . $product->id,
            'stock' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'brand_id' => 'required|exists:brands,id',
            'description' => 'required|min:10|max:255',
            'base_price' => 'required|numeric|min:0',
            'offer_price' => 'nullable|numeric|min:0|lt:base_price',
            'product_image' => 'nullable|array',
            'product_image.*' => 'image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        $product->update([
            'name' => $data['name'],
            'category_id' => $data['category_id'],
            'brand_id' => $data['brand_id'],
            'sku' => $data['sku'],
            'stock' => $data['stock'],
            'description' => $data['description'],
            'base_price' => $data['base_price'],
            'offer_price' => $data['offer_price'] ?? null,
        ]);

        if ($request->hasFile('product_image')) {
            foreach ($product->images ?? [] as $path) {
                Storage::disk('public')->delete($path);
            }

            $paths = [];
            foreach ($request->file('product_image') as $image) {
                $paths[] = $image->store('products', 'public');
            }
            $product->update(['images' => $paths]);
        }

        return redirect()->route('admin.products.index')->with('success', 'Product updated successfully.');
    }

    public function destroy(Product $product)
    {
        foreach ($product->images ?? [] as $path) {
            Storage::disk('public')->delete($path);
        }

        $product->delete();

        return redirect()->route('admin.products.index')->with('success', 'Product deleted successfully.');
    }
}
