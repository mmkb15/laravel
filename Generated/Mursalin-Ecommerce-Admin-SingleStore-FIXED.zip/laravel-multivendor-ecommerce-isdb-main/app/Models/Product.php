<?php

namespace App\Models;

use Database\Factories\ProductFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    /** @use HasFactory<ProductFactory> */
    use HasFactory;

    protected $fillable = [
        'sku',
        'category_id',
        'brand_id',
        'name',
        'description',
        'base_price',
        'offer_price',
        'stock',
        'images',
    ];

    protected function casts(): array
    {
        return [
            'images' => 'array',
            'base_price' => 'decimal:2',
            'offer_price' => 'decimal:2',
        ];
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }
}
