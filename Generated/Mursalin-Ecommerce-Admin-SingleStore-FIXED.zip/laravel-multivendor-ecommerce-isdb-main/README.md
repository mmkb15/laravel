# Ecommerce Admin Panel

A single-store ecommerce **admin panel** built by adapting the structure and Blade/AdminLTE design of the supplied Laravel multivendor project.

## Important scope

- Single-store / single-vendor ecommerce only.
- **No Vendor module, Vendor model, vendor routes, commission, or multivendor workflow.**
- **No public storefront, cart, checkout, or customer-facing website.**
- The project is focused on the admin panel and the ecommerce ERD/backend management flow.
- The Blade layout, sidebar/header/components, AdminLTE styling and page organization are kept close to the supplied friend project.

## Included modules

1. Admin authentication
2. Dashboard with live counts and recent orders
3. Product CRUD with multiple images, SKU, stock, category, brand, price and offer price
4. Category CRUD
5. Brand CRUD
6. User management for Admin and Customer roles
7. Order list, order details and order-status update
8. Customer/order/product relationships
9. Spatie Media Library for product/profile images
10. AdminLTE 4 Blade layout/components from the supplied project structure

## Demo login

- Email: `admin@example.com`
- Password: `password`

## Windows / XAMPP setup

```bash
composer install
copy .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan storage:link
npm install
npm run build
php artisan serve
```

Then open:

`http://127.0.0.1:8000/admin/login`

### MySQL

Create an empty database named `ecommerce_admin`, then keep these values in `.env`:

```env
APP_NAME="Ecommerce Admin"
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecommerce_admin
DB_USERNAME=root
DB_PASSWORD=
```

If your MySQL username/password is different, change only those values.

## Main admin routes

- `/admin/login`
- `/`
- `/admin/products`
- `/admin/categories`
- `/admin/brands`
- `/admin/orders`
- `/admin/users`
- `/profile`

## Design source

The admin Blade layout intentionally follows the supplied friend's project structure instead of introducing a new frontend theme.
