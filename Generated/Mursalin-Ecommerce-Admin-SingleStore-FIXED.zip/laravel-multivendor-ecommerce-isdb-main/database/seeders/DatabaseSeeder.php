<?php

namespace Database\Seeders;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Role::insert([
            ['id' => 1, 'name' => 'Admin', 'created_at' => now(), 'updated_at' => now()],
            ['id' => 2, 'name' => 'Customer', 'created_at' => now(), 'updated_at' => now()],
        ]);

        $admin = User::create([
            'name' => 'Admin',
            'role_id' => 1,
            'email' => 'admin@example.com',
            'phone' => '01700000000',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);

        $customers = User::factory(12)->create();

        Category::insert([
            ['name' => 'Electronics', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Fashion', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Home & Living', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Accessories', 'created_at' => now(), 'updated_at' => now()],
        ]);

        Brand::insert([
            ['name' => 'Samsung', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Aarong', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Apex', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Walton', 'created_at' => now(), 'updated_at' => now()],
        ]);

        Product::factory(30)->create();

        $products = Product::take(12)->get();
        foreach ($customers->take(8) as $index => $customer) {
            $items = $products->slice(($index % 4), 2);
            $subtotal = 0;
            $order = Order::create([
                'order_number' => 'ORD-' . now()->format('Ymd') . '-' . str_pad((string) ($index + 1), 4, '0', STR_PAD_LEFT),
                'customer_id' => $customer->id,
                'status' => ['pending', 'processing', 'shipped', 'delivered'][$index % 4],
                'payment_method' => 'cash_on_delivery',
                'shipping_name' => $customer->name,
                'shipping_phone' => $customer->phone,
                'shipping_address' => 'Dhaka, Bangladesh',
            ]);

            foreach ($items as $product) {
                $price = (float) ($product->offer_price ?: $product->base_price);
                $qty = ($index % 3) + 1;
                $lineTotal = $price * $qty;
                $subtotal += $lineTotal;
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'unit_price' => $price,
                    'quantity' => $qty,
                    'line_total' => $lineTotal,
                ]);
            }

            $order->update([
                'subtotal' => $subtotal,
                'shipping_cost' => 60,
                'total' => $subtotal + 60,
            ]);
        }
    }
}
