<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title', 'Mursalin Ecommerce'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin-fixes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icon/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>"><?php echo $__env->yieldContent('style'); ?>
</head>

<body class="body">
    <div id="wrapper">
        <div id="page"><?php echo $__env->yieldContent('content'); ?></div>
    </div>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/admin-alerts.js')); ?>"></script><?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH G:\Mursalin_1295365\Laravel\ecommerce\resources\views/admin/layouts/single.blade.php ENDPATH**/ ?>