

<?php $__env->startSection('title', 'Guest Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-wrap">
    <div class="flex items-center flex-wrap justify-between gap20 ecom-page-header">
        <div>
            <h3>Guest Customers</h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li><a href="<?php echo e(route('dashboard')); ?>"><div class="text-tiny">Dashboard</div></a></li>
                <li><i class="icon-chevron-right"></i></li>
                <li><a href="<?php echo e(route('users.index')); ?>"><div class="text-tiny">Users</div></a></li>
                <li><i class="icon-chevron-right"></i></li>
                <li><div class="text-tiny">Guest Customers</div></li>
            </ul>
        </div>
        <div class="flex items-center flex-wrap gap10">
            <a class="tf-button style-2" href="<?php echo e(route('users.index')); ?>">Registered Users</a>
        </div>
    </div>

    <div class="wg-box">
        <div class="flex items-center flex-wrap gap10">
            <a class="tf-button style-2" href="<?php echo e(route('users.index')); ?>">Registered Users</a>
            <a class="tf-button" href="<?php echo e(route('users.guests')); ?>">Guest Customers</a>
        </div>
        <div class="ecom-toolbar">
            <form class="ecom-search" method="GET" action="<?php echo e(route('users.guests')); ?>">
                <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search guest customer, email or phone...">
                <button type="submit" aria-label="Search"><i class="icon-search"></i></button>
            </form>
            <div class="ecom-search-count"><?php echo e($guestCustomers->total()); ?> guest customer(s)</div>
        </div>

        <div class="ecom-table-wrap">
            <div class="ecom-table ecom-user-table">
                <div class="ecom-table-head">
                    <div class="cell">User</div>
                    <div class="cell">Email</div>
                    <div class="cell">Phone</div>
                    <div class="cell">Role</div>
                    <div class="cell cell-right">Action</div>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $guestCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="ecom-table-row">
                        <div class="cell">
                            <div class="ecom-user-cell">
                                <div class="ecom-thumb user">
                                    <img src="<?php echo e($customer->image_url); ?>" alt="<?php echo e($customer->name); ?>">
                                </div>
                                <div class="min-w-0">
                                    <div class="ecom-primary text-truncate"><?php echo e($customer->name); ?></div>
                                    <div class="ecom-muted">
                                        #<?php echo e($customer->id); ?>

                                        ·
                                        <a href="<?php echo e(route('orders.index', ['search' => $customer->name])); ?>" class="ecom-muted">
                                            <?php echo e($customer->orders_count); ?> <?php echo e(\Illuminate\Support\Str::plural('order', $customer->orders_count)); ?>

                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cell text-truncate"><?php echo e($customer->email ?: '—'); ?></div>
                        <div class="cell"><?php echo e($customer->phone); ?></div>
                        <div class="cell"><span class="ecom-status">Guest</span></div>
                        <div class="cell">
                            <div class="ecom-actions">
                                <a href="<?php echo e(route('users.guests.edit', $customer)); ?>" class="item edit" title="Edit guest customer"><i class="icon-edit-3"></i></a>
                                <form method="POST" action="<?php echo e(route('users.guests.destroy', $customer)); ?>" onsubmit="return confirm('Delete this guest profile? Their order history will be kept.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="item trash" type="submit" title="Delete guest profile"><i class="icon-trash-2"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="ecom-empty">No guest customers found.</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="ecom-pagination"><?php echo e($guestCustomers->onEachSide(1)->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u752250113/domains/salmon-horse-851873.hostingersite.com/ecommerce/resources/views/admin/pages/user/guests.blade.php ENDPATH**/ ?>