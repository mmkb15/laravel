<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrap-login-page ecom-auth-page ecom-login-page">
    <div class="flex-grow flex flex-column justify-center gap30">
        <a href="<?php echo e(route('home')); ?>" class="auth-logo brand admin-brand" aria-label="Carto">
            <span class="brand-mark">C</span>
            Carto
        </a>

        <div class="login-box auth-login-box">
            <div class="auth-heading">
                <div class="auth-icon"><i class="icon-lock"></i></div>
                <div>
                    <h3>Welcome back</h3>
                    <div class="body-text">Sign in to your Carto account</div>
                </div>
            </div>

            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','class' => 'auth-alert','messages' => session('success')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','class' => 'auth-alert','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','class' => 'auth-alert','messages' => $errors->all()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','class' => 'auth-alert','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->all())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

            <form class="form-login flex flex-column gap24" method="POST" action="<?php echo e(route('login.store')); ?>">
                <?php echo csrf_field(); ?>

                <?php
                    $demoAccounts = [
                        ['label' => 'Try Admin Demo', 'account' => config('app.demo_accounts.admin')],
                        ['label' => 'Try Customer Demo', 'account' => config('app.demo_accounts.customer')],
                    ];
                ?>

                <?php if(collect($demoAccounts)->contains(fn ($demo) => filled($demo['account']['email']) && filled($demo['account']['password']))): ?>
                    <div class="demo-access">
                        <div class="body-text">Choose a demo role</div>
                        <div class="demo-access-buttons">
                            <?php $__currentLoopData = $demoAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(filled($demo['account']['email']) && filled($demo['account']['password'])): ?>
                                    <button
                                        class="tf-button style-2"
                                        type="button"
                                        data-demo-email="<?php echo e($demo['account']['email']); ?>"
                                        data-demo-password="<?php echo e($demo['account']['password']); ?>"
                                    >
                                        <?php echo e($demo['label']); ?>

                                    </button>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="text-tiny">Select a role to fill the form, then click Login.</div>
                    </div>
                <?php endif; ?>

                <fieldset class="template-field">
                    <label for="email">Email Address <span class="required">*</span></label>
                    <input id="email" class="template-input" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your email address" autocomplete="email" required>
                </fieldset>

                <fieldset class="template-field password">
                    <label for="password">Password <span class="required">*</span></label>
                    <div class="auth-password-field">
                        <input id="password" class="template-input password-input" type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                        <button type="button" class="show-pass auth-password-toggle" aria-label="Show password">
                            <i class="icon-eye view"></i>
                            <i class="icon-eye-off hide"></i>
                        </button>
                    </div>
                </fieldset>

                <div class="flex items-center justify-between gap15 flex-wrap">
                    <label class="auth-check">
                        <input type="checkbox" name="remember" value="1">
                        <span>Keep me signed in</span>
                    </label>
                </div>

                <div class="text-right">
                    <a href="<?php echo e(route('password.request')); ?>" class="body-text tf-color">Forgot password?</a>
                </div>

                <button class="tf-button w-full" type="submit">
                    <i class="icon-log-in"></i>
                    Login
                </button>
            </form>

            <div class="body-text text-center">
                New to Carto?
                <a href="<?php echo e(route('register')); ?>" class="body-text tf-color">Register Now</a>
            </div>
            <a class="demo-guest-link" href="<?php echo e(rtrim(config('app.frontend_url'), '/').'/'); ?>">Continue as guest</a>
        </div>
    </div>

    <div class="text-tiny">© <?php echo e(date('Y')); ?> | All Rights Reserved. Developed by Mustafa Mursalin Khan (1295365) (WDPF Round-70) as an assignment of ISDB-BISEW IT Scholarship Programme</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-demo-email]').forEach(function (button) {
            button.addEventListener('click', function () {
                document.getElementById('email').value = button.dataset.demoEmail;
                document.getElementById('password').value = button.dataset.demoPassword;
                document.querySelector('input[name="remember"]').checked = false;
            });
        });

        document.querySelectorAll('.auth-password-toggle').forEach(function (button) {
            button.addEventListener('click', function () {
                const input = button.closest('.auth-password-field').querySelector('input');
                const isPassword = input.type === 'password';
                input.type = isPassword ? 'text' : 'password';
                button.classList.toggle('active', isPassword);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.single', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\New folder 2.0\WDPF\WDPF70\laravel\ecommerce\resources\views/admin/pages/auth/login.blade.php ENDPATH**/ ?>