<div class="bottom-page">
    <div class="body-text">© <?php echo e(date('Y')); ?> | All Rights Reserved. Developed by Mustafa Mursalin Khan (1295365)
        (WDPF Round-70) as an assignment of ISDB-BISEW IT Scholarship Programme</div>
</div>
<?php /**PATH X:\New folder 2.0\WDPF\WDPF70\laravel\ecommerce\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>