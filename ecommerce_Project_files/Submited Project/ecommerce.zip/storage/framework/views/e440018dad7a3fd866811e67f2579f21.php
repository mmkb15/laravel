<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title', 'Mursalin Ecommerce'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Outfit:wght@400;500;600;700&family=Roboto+Mono:wght@400;500&display=swap">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin-fixes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icon/style.css')); ?>">
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/images/logo/logo.svg')); ?>"><?php echo $__env->yieldContent('style'); ?>
</head>

<body class="body">
    <div id="wrapper">
        <div id="page"><?php echo $__env->yieldContent('content'); ?></div>
    </div>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/admin-alerts.js')); ?>"></script><?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH X:\New folder 2.0\WDPF\WDPF70\laravel\ecommerce_0.3\resources\views/admin/layouts/single.blade.php ENDPATH**/ ?>