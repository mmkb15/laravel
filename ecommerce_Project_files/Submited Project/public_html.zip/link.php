<?php
$target = '/home/u752250113/domains/salmon-horse-851873.hostingersite.com/ecommerce/storage/app/public';
$link   = '/home/u752250113/domains/salmon-horse-851873.hostingersite.com/public_html/storage';

if (symlink($target, $link)) {
    echo 'Symlink created';
} else {
    echo 'Failed';
}